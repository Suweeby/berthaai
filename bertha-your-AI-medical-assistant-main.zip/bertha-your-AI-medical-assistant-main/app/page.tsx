"use client"

import App from "@/components/app"

export default function Home() {
  return <App />
}

